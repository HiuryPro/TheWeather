from django.conf import settings


settings.configure()
